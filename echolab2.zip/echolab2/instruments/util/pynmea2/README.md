## pynmea2

pynmea2 is adapted from Tom Flanagan's [pynmea2](https://github.com/Knio/pynmea2) python library to work with pyEcholab.